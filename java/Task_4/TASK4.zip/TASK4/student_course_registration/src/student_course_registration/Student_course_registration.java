/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package student_course_registration;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author admin
 */
public class Student_course_registration implements ActionListener {

    JFrame jf;
    JScrollPane jsp, jsp2;
    JTabbedPane jtb;
    JPanel courses, student, enroll, drop;
    JLabel show_res;
    DefaultTableModel jtb_tbl, jtb_tbl2;
    JTable jtb_table, jtb_table2;
    Connection con;
    Statement stmt;
    JTextField studentid, studentname, course,drop_course;
    JLabel jlb_studentid, jlb_studentname, jlb_course,jlb_drp_course;
    JButton jb_enroll, jb_delete;

    public Student_course_registration() {
        jf = new JFrame();
        jf.setVisible(true);
        jf.setSize(600, 600);
        jtb = new JTabbedPane(1);

        courses = new JPanel();
        courses.setLayout(null);
        courses.setLayout(new BorderLayout());
        displayCourseInformation();
        jtb.add("COURSES", courses);

        student = new JPanel();
        student.setLayout(null);
        student.setLayout(new BorderLayout());
        displayStudentInformation();
        jtb.add("STUDENT", student);
        

        enroll = new JPanel();
        enroll.setLayout(null);
        jlb_studentid = new JLabel("STUDENT ID");
        jlb_studentid.setBounds(20, 0, 110, 110);
        studentid = new JTextField();
        studentid.setBounds(160, 45, 200, 20);
        enroll.add(studentid);
        enroll.add(jlb_studentid);
        jlb_studentname = new JLabel("STUDENT NAME");
        jlb_studentname.setBounds(20, 35, 110, 110);
        studentname = new JTextField();
        studentname.setBounds(160, 80, 200, 20);
        enroll.add(jlb_studentname);
        enroll.add(studentname);
        jlb_course = new JLabel("COURSE");
        jlb_course.setBounds(20, 70, 110, 110);
        course = new JTextField();
        course.setBounds(160, 115, 200, 20);
        enroll.add(course);
        enroll.add(jlb_course);
        jb_enroll = new JButton("INSERT");
        jb_enroll.setBounds(170, 180, 100, 30);
        jb_enroll.addActionListener(this);
        enroll.add(jb_enroll);
        jtb.add("ENROLL IN COURSE", enroll);

        drop = new JPanel();
        drop.setLayout(null);
         jlb_drp_course = new JLabel("STUDENT ID");
        jlb_drp_course.setBounds(20, 0, 110, 110);
        drop_course = new JTextField();
        drop_course.setBounds(160, 45, 200, 20);
       drop.add(jlb_drp_course);
       drop.add(drop_course);
        jb_delete = new JButton("DELETE");
        jb_delete.setBounds(180, 170, 100, 30);
        jb_delete.addActionListener(this);
        drop.add(jb_delete);
        jtb.add("DROP FROM COURSE", drop);
        
        jf.add(jtb);
    }

    public void con_mthd() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/CodSoft", "root", "");
            stmt = con.createStatement();
//            System.out.println("hello");
        } catch (Exception e) {
            System.out.println("error generated in con_mthd " + e.toString());
        }
    }

    public void displayStudentInformation() {
        jtb_tbl2 = new DefaultTableModel();
        jtb_tbl2.addColumn("STUDENT ID");
        jtb_tbl2.addColumn("STUDENT NAME");
        jtb_tbl2.addColumn("STUDENT COURSE");

        try {
            con_mthd();
            ResultSet res = stmt.executeQuery("select *from  student");
            while (res.next()) {

                String Studentid, Studentname, Course;
                Studentid = res.getString(1);
                Studentname = res.getString(2);
                Course = res.getString(3);

                jtb_tbl2.addRow(new Object[]{Studentid, Studentname, Course});

            }
        } catch (Exception displayTableEX) {
            System.out.println("ERROR IN DISPLAY TABLE" + displayTableEX.getMessage());
        }
        jtb_table2 = new JTable(jtb_tbl2);
        jtb_table2.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        jsp2 = new JScrollPane(jtb_table2, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        student.add(jsp2);
    }

    public void displayCourseInformation() {
        jtb_tbl = new DefaultTableModel();
        jtb_tbl.addColumn("Corse Code");
        jtb_tbl.addColumn("Title");
        jtb_tbl.addColumn("Description");
        jtb_tbl.addColumn("Capacity");
        jtb_tbl.addColumn("Schedule");
        try {
            con_mthd();
            ResultSet res = stmt.executeQuery("select *from  course");
            while (res.next()) {

                int capacity;
                String title, description, schedule, coursecode;
                coursecode = res.getString(1);
                title = res.getString(2);
                description = res.getString(3);
                capacity = res.getInt(4);
                schedule = res.getString(5);
                jtb_tbl.addRow(new Object[]{coursecode, title, description, capacity, schedule});

            }
        } catch (Exception displayTableEX) {
            System.out.println("ERROR IN DISPLAY TABLE" + displayTableEX.getMessage());
        }
        jtb_table = new JTable(jtb_tbl);
        jtb_table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        jsp = new JScrollPane(jtb_table, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        courses.add(jsp);

    }

    public static void main(String[] args) {
        Student_course_registration sj = new Student_course_registration();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("INSERT")) {

            try {
                con_mthd();
                String studentnamest, studentidst, studentcoursest;
                studentnamest = studentname.getText();
                studentidst = studentid.getText();
                studentcoursest = course.getText();

                stmt.executeUpdate("insert into student values('" + studentidst + "','" + studentnamest + "','" + studentcoursest + "')");

                JOptionPane.showMessageDialog(jf, "Inserted successfully");

            } catch (Exception insrtex) {
                JOptionPane.showMessageDialog(jf, insrtex.getMessage());
            }

        }
         if (e.getActionCommand().equals("DELETE")) {
            try {
                con_mthd();
                String studentid;
                studentid = drop_course.getText();
                stmt.executeUpdate("delete from student where Studentid= '" + studentid + "';");
                JOptionPane.showMessageDialog(jf, "deleted successfully");
            } catch (Exception e3) {
                JOptionPane.showMessageDialog(jf, e3.toString());
            }
        }
    }

}
